# AlgoCampus

A simple, attractive, full-stack DSA learning and visualization platform.

## Stack
- React + Vite + JavaScript + CSS
- Node.js + Express
- Pure JavaScript DSA engine
- MongoDB (optional for local demo; required for persistent accounts/progress)
- JWT + bcrypt authentication

## Features
- Dashboard with topic overview and progress
- Interactive Array, Stack, Queue, Linked List and Graph playgrounds
- Sorting visualizer (Bubble, Selection, Insertion)
- Searching visualizer (Linear, Binary)
- Step-by-step controls, speed control, reset and custom input
- Complexity reference
- Quiz with score feedback
- Register/login and progress API when MongoDB is configured
- Responsive dark interface

## Windows setup

1. Install Node.js LTS and MongoDB Community Server (or create a MongoDB Atlas database).
2. Extract this ZIP.
3. Open a terminal in the `AlgoCampus` folder.
4. Run:
   ```bash
   npm install
   npm run install:all
   ```
5. Copy `backend/.env.example` to `backend/.env` and set `MONGO_URI` and `JWT_SECRET`.
6. Start both applications:
   ```bash
   npm run dev
   ```
7. Open `http://localhost:5173`.

The frontend works in demo mode without MongoDB. Authentication and persistent progress require a reachable MongoDB instance.

## Separate start commands
- Backend: `npm run dev --prefix backend` (http://localhost:5000)
- Frontend: `npm run dev --prefix frontend` (http://localhost:5173)

## Project structure
- `frontend/` React application and browser-side DSA engine
- `backend/` Express API, authentication and MongoDB models
- `docs/` architecture and API notes

## Notes
- The browser-side DSA engine performs the visualized operations directly in JavaScript.
- This is an educational project, not a production-grade online judge. Arbitrary code execution is intentionally not exposed.
- Change the demo UI data and add topics/problems as needed for your course.
