// Pure JavaScript DSA helpers. These are real operations used by the playground.
export class Stack {
  constructor(items=[]) { this.items=[...items]; }
  push(v) { this.items.push(v); return this.items; }
  pop() { return this.items.pop(); }
  peek() { return this.items.at(-1); }
}
export class Queue {
  constructor(items=[]) { this.items=[...items]; }
  enqueue(v) { this.items.push(v); return this.items; }
  dequeue() { return this.items.shift(); }
  front() { return this.items[0]; }
}
export class LinkedList {
  constructor(values=[]) { this.head=null; values.forEach(v=>this.append(v)); }
  append(value) { const node={value,next:null}; if(!this.head){this.head=node;return;} let n=this.head;while(n.next)n=n.next;n.next=node; }
  prepend(value) { this.head={value,next:this.head}; }
  remove(value) { if(!this.head)return false; if(this.head.value===value){this.head=this.head.next;return true;} let n=this.head;while(n.next&&n.next.value!==value)n=n.next;if(!n.next)return false;n.next=n.next.next;return true; }
  toArray() { const out=[];let n=this.head;while(n){out.push(n.value);n=n.next;}return out; }
}
export function bubbleSortSteps(input) {
  const a=[...input], steps=[{array:[...a], active:[]}];
  for(let i=0;i<a.length-1;i++) for(let j=0;j<a.length-i-1;j++) {
    steps.push({array:[...a],active:[j,j+1],message:`Compare ${a[j]} and ${a[j+1]}`});
    if(a[j]>a[j+1]) { [a[j],a[j+1]]=[a[j+1],a[j]]; steps.push({array:[...a],active:[j,j+1],message:'Swap the two values'}); }
  }
  steps.push({array:[...a],active:[],message:'Array is sorted.'}); return steps;
}
export function selectionSortSteps(input) {
  const a=[...input], steps=[{array:[...a],active:[]}];
  for(let i=0;i<a.length-1;i++){let min=i;for(let j=i+1;j<a.length;j++){steps.push({array:[...a],active:[min,j],message:`Find the minimum for position ${i}`});if(a[j]<a[min])min=j;}if(min!==i)[a[i],a[min]]=[a[min],a[i]];steps.push({array:[...a],active:[i,min],message:'Place the smallest value in its position'});}
  steps.push({array:[...a],active:[],message:'Array is sorted.'});return steps;
}
export function insertionSortSteps(input) {
 const a=[...input],steps=[{array:[...a],active:[]}];
 for(let i=1;i<a.length;i++){let key=a[i],j=i-1;while(j>=0&&a[j]>key){a[j+1]=a[j];steps.push({array:[...a],active:[j,j+1],message:`Shift ${a[j]} one position right`});j--;}a[j+1]=key;steps.push({array:[...a],active:[j+1],message:`Insert ${key} into the sorted section`});}
 steps.push({array:[...a],active:[],message:'Array is sorted.'});return steps;
}
export function linearSearchSteps(a,target){const s=[];for(let i=0;i<a.length;i++){s.push({index:i,message:`Check index ${i}: ${a[i]}`});if(a[i]===target){s.push({index:i,found:true,message:`Found ${target} at index ${i}.`});return s;}}s.push({index:-1,found:false,message:`${target} was not found.`});return s;}
export function binarySearchSteps(a,target){const sorted=[...a].sort((x,y)=>x-y),s=[];let l=0,r=sorted.length-1;while(l<=r){const m=Math.floor((l+r)/2);s.push({index:m,left:l,right:r,message:`Check middle value ${sorted[m]}`});if(sorted[m]===target){s.push({index:m,found:true,message:`Found ${target} at index ${m} in the sorted array.`});return s;}if(sorted[m]<target)l=m+1;else r=m-1;}s.push({index:-1,found:false,message:`${target} was not found.`});return s;}
export function bfs(graph,start){const visited=new Set([start]),q=[start],order=[];while(q.length){const v=q.shift();order.push(v);(graph[v]||[]).forEach(n=>{if(!visited.has(n)){visited.add(n);q.push(n);}});}return order;}
