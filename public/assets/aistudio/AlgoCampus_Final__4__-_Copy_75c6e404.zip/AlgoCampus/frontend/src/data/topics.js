export const topics = [
 {id:'arrays',title:'Arrays',category:'Linear structures',level:'Beginner',desc:'Indexed collections with fast access.',icon:'▦',time:'12 min',complexity:'Access O(1)'},
 {id:'stacks',title:'Stacks',category:'Linear structures',level:'Beginner',desc:'Last In, First Out data handling.',icon:'▤',time:'10 min',complexity:'Push O(1)'},
 {id:'queues',title:'Queues',category:'Linear structures',level:'Beginner',desc:'First In, First Out data handling.',icon:'⇥',time:'10 min',complexity:'Enqueue O(1)'},
 {id:'linked-list',title:'Linked Lists',category:'Linear structures',level:'Intermediate',desc:'Nodes connected through references.',icon:'⛓',time:'18 min',complexity:'Search O(n)'},
 {id:'graphs',title:'Graphs',category:'Non-linear structures',level:'Intermediate',desc:'Vertices and edges model relationships.',icon:'⌘',time:'22 min',complexity:'BFS O(V + E)'},
 {id:'sorting',title:'Sorting',category:'Algorithms',level:'Beginner',desc:'Arrange values using classic strategies.',icon:'↕',time:'20 min',complexity:'Bubble O(n²)'},
 {id:'searching',title:'Searching',category:'Algorithms',level:'Beginner',desc:'Find values efficiently in collections.',icon:'⌕',time:'14 min',complexity:'Binary O(log n)'},
 {id:'complexity',title:'Complexity',category:'Foundations',level:'Beginner',desc:'Understand algorithm performance growth.',icon:'◷',time:'15 min',complexity:'Big O'}
];
