import axios from 'axios';
export const api=axios.create({baseURL:import.meta.env.VITE_API_URL||'http://localhost:5000/api'});
api.interceptors.request.use(config=>{const token=localStorage.getItem('ac_token');if(token)config.headers.Authorization=`Bearer ${token}`;return config;});
export async function saveProgress(topicId){try{await api.post('/progress',{topicId});}catch{/* Demo mode remains available without a signed-in account. */}}
