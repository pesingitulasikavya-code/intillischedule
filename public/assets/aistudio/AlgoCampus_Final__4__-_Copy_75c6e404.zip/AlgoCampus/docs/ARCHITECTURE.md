# AlgoCampus architecture

The React client owns interactive visualization state. DSA operations are implemented as plain JavaScript modules in `frontend/src/engine`; visualizers consume generated steps and render them.

The Express API provides registration, login, current-user lookup, topic listing and progress persistence. MongoDB is accessed through Mongoose. If MongoDB is not configured, the client remains usable in local demo mode, but account persistence is unavailable.

## API
- `POST /api/auth/register` — create account
- `POST /api/auth/login` — authenticate and receive JWT
- `GET /api/auth/me` — current account (Bearer token)
- `GET /api/topics` — topic catalogue
- `GET /api/progress` — current user's progress (Bearer token)
- `POST /api/progress` — save completed topic (Bearer token)
- `GET /api/health` — API status
