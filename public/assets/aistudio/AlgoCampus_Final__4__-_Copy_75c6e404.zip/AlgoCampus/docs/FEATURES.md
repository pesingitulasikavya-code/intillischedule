# Implemented feature map

- Dashboard and topic catalogue
- Search and category filtering
- Array, stack, queue and linked-list operations
- Bubble, selection and insertion sort step generation
- Linear and binary search step generation
- Play/pause, next/previous, restart and speed selection
- Big-O reference table
- Four-question DSA quiz with explanations and score
- Express REST API, MongoDB models, JWT registration/login and progress endpoints

## Planned extensions
Additional tree, heap, hash-table, graph editing, BFS/DFS animation, richer coding challenge authoring, admin content management and production-grade isolated code execution can be added as later modules.
