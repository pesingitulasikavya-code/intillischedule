import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import authRoutes from './src/routes/auth.js';
import progressRoutes from './src/routes/progress.js';
import { topics } from './src/data/topics.js';

dotenv.config();
const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json());

app.get('/api/health', (_req, res) => res.json({ status: 'ok', app: 'AlgoCampus API' }));
app.get('/api/topics', (_req, res) => res.json(topics));
app.use('/api/auth', authRoutes);
app.use('/api/progress', progressRoutes);

const port = process.env.PORT || 5000;
if (process.env.MONGO_URI) {
  mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error('MongoDB connection failed:', err.message));
}
app.listen(port, () => console.log(`AlgoCampus API running on http://localhost:${port}`));
