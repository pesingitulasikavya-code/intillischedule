export const topics = [
 { id:'arrays', title:'Arrays', category:'Linear structures', level:'Beginner', description:'Store and access indexed collections of values.', complexity:'Access O(1) · Search O(n)' },
 { id:'stacks', title:'Stacks', category:'Linear structures', level:'Beginner', description:'Explore Last In, First Out operations.', complexity:'Push O(1) · Pop O(1)' },
 { id:'queues', title:'Queues', category:'Linear structures', level:'Beginner', description:'Explore First In, First Out operations.', complexity:'Enqueue O(1) · Dequeue O(1)' },
 { id:'linked-list', title:'Linked Lists', category:'Linear structures', level:'Intermediate', description:'Connect nodes using references and pointers.', complexity:'Insert head O(1) · Search O(n)' },
 { id:'graphs', title:'Graphs', category:'Non-linear structures', level:'Intermediate', description:'Model relationships with vertices and edges.', complexity:'BFS O(V + E) · DFS O(V + E)' },
 { id:'sorting', title:'Sorting', category:'Algorithms', level:'Beginner', description:'Arrange values using classic sorting strategies.', complexity:'Bubble O(n²) · Merge O(n log n)' },
 { id:'searching', title:'Searching', category:'Algorithms', level:'Beginner', description:'Find target values in collections.', complexity:'Linear O(n) · Binary O(log n)' },
 { id:'complexity', title:'Complexity', category:'Foundations', level:'Beginner', description:'Understand time and space growth.', complexity:'Big O notation' }
];
