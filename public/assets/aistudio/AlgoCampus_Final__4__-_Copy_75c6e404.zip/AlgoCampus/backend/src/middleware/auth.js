import jwt from 'jsonwebtoken';
export default function auth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message:'Authentication required' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET || 'development_only_secret');
    next();
  } catch { return res.status(401).json({ message:'Invalid or expired token' }); }
}
