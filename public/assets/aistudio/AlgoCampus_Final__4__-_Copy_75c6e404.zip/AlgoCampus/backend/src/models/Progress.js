import mongoose from 'mongoose';
const progressSchema = new mongoose.Schema({
  user: { type:mongoose.Schema.Types.ObjectId, ref:'User', required:true },
  topicId: { type:String, required:true },
  completedAt: { type:Date, default:Date.now }
});
progressSchema.index({ user:1, topicId:1 }, { unique:true });
export default mongoose.model('Progress', progressSchema);
