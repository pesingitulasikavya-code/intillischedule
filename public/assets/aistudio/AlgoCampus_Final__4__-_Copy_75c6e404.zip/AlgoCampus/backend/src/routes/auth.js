import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import auth from '../middleware/auth.js';
const router = Router();
const sign = user => jwt.sign({ id:user._id, name:user.name, email:user.email }, process.env.JWT_SECRET || 'development_only_secret', { expiresIn:'7d' });
router.post('/register', async (req,res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password || password.length < 6) return res.status(400).json({ message:'Enter name, email and a password of at least 6 characters.' });
    const exists = await User.findOne({ email });
    if (exists) return res.status(409).json({ message:'An account with this email already exists.' });
    const user = await User.create({ name, email, password:await bcrypt.hash(password, 12) });
    res.status(201).json({ token:sign(user), user:{ id:user._id, name:user.name, email:user.email } });
  } catch (e) { res.status(500).json({ message:'Could not create account. Check MongoDB connection.' }); }
});
router.post('/login', async (req,res) => {
  try {
    const user = await User.findOne({ email:req.body.email });
    if (!user || !await bcrypt.compare(req.body.password || '', user.password)) return res.status(401).json({ message:'Incorrect email or password.' });
    res.json({ token:sign(user), user:{ id:user._id, name:user.name, email:user.email } });
  } catch { res.status(500).json({ message:'Login unavailable. Check MongoDB connection.' }); }
});
router.get('/me', auth, async (req,res) => {
  const user = await User.findById(req.user.id).select('-password');
  if (!user) return res.status(404).json({ message:'User not found' });
  res.json({ id:user._id, name:user.name, email:user.email });
});
export default router;
