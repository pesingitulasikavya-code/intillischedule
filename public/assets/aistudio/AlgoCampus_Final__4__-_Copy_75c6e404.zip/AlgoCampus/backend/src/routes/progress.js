import { Router } from 'express';
import Progress from '../models/Progress.js';
import auth from '../middleware/auth.js';
const router = Router();
router.use(auth);
router.get('/', async (req,res) => {
  try { res.json(await Progress.find({ user:req.user.id }).sort({ completedAt:-1 })); }
  catch { res.status(500).json({ message:'Could not load progress' }); }
});
router.post('/', async (req,res) => {
  try {
    if (!req.body.topicId) return res.status(400).json({ message:'topicId is required' });
    const item = await Progress.findOneAndUpdate(
      { user:req.user.id, topicId:req.body.topicId },
      { $setOnInsert:{ user:req.user.id, topicId:req.body.topicId } },
      { upsert:true, new:true }
    );
    res.json(item);
  } catch { res.status(500).json({ message:'Could not save progress' }); }
});
export default router;
